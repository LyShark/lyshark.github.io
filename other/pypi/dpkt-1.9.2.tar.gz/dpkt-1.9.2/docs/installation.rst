============
Installation
============

DKPT is now available directly from pypi :)

Install the Code
----------------

::

    pip install dpkt

Checkout the Code
-----------------

::

    git clone https://github.com/kbandla/dpkt.git



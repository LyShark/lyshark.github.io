﻿【食用方式】

1.选择后端主题为 elf 并禁用CSS

2.将custom.css粘贴到 【页面定制 CSS 代码】

3.footer.html 粘贴到 【页脚 HTML 代码】

4.header.html 粘贴到 【页首 HTML 代码】

5.sidebar.html 粘贴到 【博客侧边栏公告（支持HTML代码） （支持 JS 代码）】

预览效果：https://www.cnblogs.com/lyshark

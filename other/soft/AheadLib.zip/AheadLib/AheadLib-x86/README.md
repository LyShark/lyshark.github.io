AheadLib
========

Fake DLL Source Code Generator

AheadLib 2.2.150 - 自动生成一个特洛伊 DLL 分析代码的工具

![](http://yonsm.net/assets/1097248756.gif)

Ref to: <http://yonsm.net/aheadlib/>

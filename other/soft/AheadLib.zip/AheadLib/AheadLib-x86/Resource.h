//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDD_Main                        100
#define IDI_Main                        102
#define IDC_DllFile                     1000
#define IDC_BrowseDll                   1001
#define IDC_CppFile                     1002
#define IDC_BrowseCpp                   1003
#define IDC_Options                     1004
#define IDC_About                       1005
#define IDC_CallRedirect                1006
#define IDC_CallInTime                  1007
#define IDC_LoadInEntry                 1008
#define IDC_LoadIfNeed                  1009
#define IDC_JumpToOrigin                1010
#define IDC_CallOrigin                  1011
#define IDC_MultiThread                 1012
#define IDC_OriginDll                   1013
#define IDC_SystemPath                  1014
#define IDC_GenerateHook                1016
#define IDC_Preview                     1017
#define IDC_CheckUpdate                 1018
#define IDC_STATIC                      -1


// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        10400
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         10280
#define _APS_NEXT_SYMED_VALUE           10100
#endif
#endif

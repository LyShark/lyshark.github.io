# AheadLib-x86-x64

## hijack dll Source Code Generator. support x86/x64 

## snapshot screen
![Image text](screen1.jpg)

## NOTE

Pay attention to the generated file header prompt information
from watchdog.observers import Observer
from watchdog.events import *
import time

class FileEventHandler(FileSystemEventHandler):
    def __init__(self):
        FileSystemEventHandler.__init__(self)

    def on_moved(self, event):
        if event.is_directory:
            print("目录 {0} 更改为 {1}".format(event.src_path,event.dest_path))
        else:
            print("文件 {0} 更改为 {1}".format(event.src_path,event.dest_path))

    def on_created(self, event):
        if event.is_directory:
            print("目录被创建:{0}".format(event.src_path))
        else:
            print("文件被创建:{0}".format(event.src_path))

    def on_deleted(self, event):
        if event.is_directory:
            print("目录被删除:{0}".format(event.src_path))
        else:
            print("文件被删除:{0}".format(event.src_path))

    def on_modified(self, event):
        if event.is_directory:
            print("目录被更改:{0}".format(event.src_path))
        else:
            print("文件被更改:{0}".format(event.src_path))

if __name__ == "__main__":
    observer = Observer()
    event_handler = FileEventHandler()
    observer.schedule(event_handler,"Z:\MyWeb",True)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
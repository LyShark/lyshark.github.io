import os,re,random,urllib,argparse
from urllib import request,parse

# 随机获取一个请求体
def GetUserAgent(url):
    UsrHead = ["Windows; U; Windows NT 6.1; en-us","Windows NT 5.1; x86_64","Ubuntu U; NT 18.04; x86_64",
    "Windows NT 10.0; WOW64","X11; Ubuntu i686;","X11; Centos x86_64;","compatible; MSIE 9.0; Windows NT 8.1;",
    "X11; Linux i686","Macintosh; U; Intel Mac OS X 10_6_8; en-us","compatible; MSIE 7.0; Windows Server 6.1",
    "Macintosh; Intel Mac OS X 10.6.8; U; en","compatible; MSIE 7.0; Windows NT 5.1","iPad; CPU OS 4_3_3;"]
    UsrFox = ["Chrome/60.0.3100.0","Auburn Browser","Safari/522.13","Chrome/80.0.1211.0","Firefox/74.0",
    "Gecko/20100101 Firefox/4.0.1","Presto/2.8.131 Version/11.11","Mobile/8J2 Safari/6533.18.5",
    "Version/4.0 Safari/534.13","wOSBrowser/233.70 Baidu Browser/534.6 TouchPad/1.0","BrowserNG/7.1.18124",
    "rident/4.0; SE 2.X MetaSr 1.0;","360SE/80.1","wOSBrowser/233.70","UCWEB7.0.2.37/28/999","Opera/UCWEB7.0.2.37"]
    UsrAgent = "Mozilla/5.0 (" + str(random.sample(UsrHead,1)[0]) + ") AppleWebKit/" + str(random.randint(100,1000)) \
    + ".36 (KHTML, like Gecko) " + str(random.sample(UsrFox,1)[0])
    
    UsrRefer = str(url + "/" + "".join(random.sample("abcdef23457sdadw",10)))
    UserAgent = {"User-Agent": UsrAgent,"Referer":UsrRefer}
    return UserAgent

# 通过内置库,获取到页面的URL源代码
def GetPageURL(page):
    head = GetUserAgent(page)
    req = request.Request(url=page,headers=head,method="GET")
    respon = request.urlopen(req,timeout=3)
    if respon.status == 200:
        html = respon.read().decode("utf-8") # 或是gbk根据页面属性而定
        return html

# 传入参数,对页面进行拼接并返回列表
def SplicingPage(page,start,end):
    url = []
    for each in range(start,end):
        temporary = page.format(each)
        url.append(temporary)
    return url
 
if __name__ == "__main__":

    urls = "https://www.meitulu.com/item/{}_{}.html".format(str(random.randint(1000,20000)),"{}")
    
    page_list = SplicingPage(urls,2,100)
    for item in page_list:
        try:
            respon = GetPageURL(str(item))
            subject = re.findall('<img src="([^"]+\.jpg)"',respon,re.S)
            for each in subject:
                img_name = each.split("/")[-1]
                img_type = each.split("/")[-1].split(".")[1]
                save_name = str(random.randint(11111111,999999999)) + "." + img_type
                print("[+] 原始名称: {} 保存为: {} 路径: {}".format(img_name,save_name,each))
                #urllib.request.urlretrieve(each,save_name,None)  # 无请求体的下载图片方式
                head = GetUserAgent(str(urls))                # 随机弹出请求头
                ret = urllib.request.Request(each,headers=head)   # each = 访问图片路径
                respons = urllib.request.urlopen(ret,timeout=10)  # 打开图片路径
                with open(save_name,"wb") as fp:
                    fp.write(respons.read())
        except Exception:
            # 删除当前目录下小于100kb的图片
            for each in os.listdir():
                if each.split(".")[1] == "jpg":
                    if int(os.stat(each).st_size / 1024) < 100:
                        print("[-] 自动清除 {} 小于100kb文件.".format(each))
                        os.remove(each)
            exit(1)
else:
    parser.print_help()
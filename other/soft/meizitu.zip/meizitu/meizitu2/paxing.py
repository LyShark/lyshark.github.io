from bs4 import BeautifulSoup
import requests

if __name__ == "__main__":

    get_url = []
    urls = requests.get("https://www.meitulu.com/t/youhuo/")
    soup = BeautifulSoup(urls.text,"html.parser")
    soup_ret = soup.select('div[class="boxs"] ul[class="img"] a')
    for each in soup_ret:
        if str(each["href"]).endswith("html"):
            get_url.append(each["href"])
            
    for item in get_url:
        for each in range(2,30):
            url = item.replace(".html","_{}.html".format(each))
            with open("url.log","a+") as fp:
                fp.write(url + "\n")
import os,sys
import subprocess

for i in range(0,200):
    try:
        os.chdir("D://python/wuso")
        cmd = "python 1.py"
        os.popen(cmd)
    except Exception:
        exit(0)
        pass
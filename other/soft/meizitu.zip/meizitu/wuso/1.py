import os,urllib,random,argparse,sys
from urllib import request,parse
from bs4 import BeautifulSoup

def GetUserAgent(url):
    UsrHead = ["Windows; U; Windows NT 6.1; en-us","Windows NT 5.1; x86_64","Ubuntu U; NT 18.04; x86_64",
    "Windows NT 10.0; WOW64","X11; Ubuntu i686;","X11; Centos x86_64;","compatible; MSIE 9.0; Windows NT 8.1;",
    "X11; Linux i686","Macintosh; U; Intel Mac OS X 10_6_8; en-us","compatible; MSIE 7.0; Windows Server 6.1",
    "Macintosh; Intel Mac OS X 10.6.8; U; en","compatible; MSIE 7.0; Windows NT 5.1","iPad; CPU OS 4_3_3;"]
    UsrFox = ["Chrome/60.0.3100.0","Auburn Browser","Safari/522.13","Chrome/80.0.1211.0","Firefox/74.0",
    "Gecko/20100101 Firefox/4.0.1","Presto/2.8.131 Version/11.11","Mobile/8J2 Safari/6533.18.5",
    "Version/4.0 Safari/534.13","wOSBrowser/233.70 Baidu Browser/534.6 TouchPad/1.0","BrowserNG/7.1.18124",
    "rident/4.0; SE 2.X MetaSr 1.0;","360SE/80.1","wOSBrowser/233.70","UCWEB7.0.2.37/28/999","Opera/UCWEB7.0.2.37"]
    UsrAgent = "Mozilla/5.0 (" + str(random.sample(UsrHead,1)[0]) + ") AppleWebKit/" + str(random.randint(100,1000)) \
    + ".36 (KHTML, like Gecko) " + str(random.sample(UsrFox,1)[0])
    
    UsrRefer = url + str("/" + "".join(random.sample("abcdefghi123457sdadw",10)))
    UserAgent = {"User-Agent": UsrAgent,"Referer":UsrRefer}
    return UserAgent

def GetPageURL(page):
    head = GetUserAgent(page)
    req = request.Request(url=page,headers=head,method="GET")
    respon = request.urlopen(req,timeout=30)
    if respon.status == 200:
        html = respon.read().decode("utf-8")
        return html

if __name__ == "__main__":
    runt = []

    waibu = GetPageURL("https://wuso.me/forum.php?mod=forumdisplay&fid=48&typeid=114&filter=typeid&typeid=114")
    soup1 = BeautifulSoup(waibu,"html.parser")
    ret1 = soup1.select("div[id='threadlist'] ul[id='waterfall'] a")
    for x in ret1:
        runt.append(x.attrs["href"])
    
    for ss in runt:
        print("[+] 爬行: {}".format(ss))
        try:
            resp = []
            respon = GetPageURL(str(ss))
            soup = BeautifulSoup(respon,"html.parser")
            ret = soup.select("div[class='pct'] div[class='pcb'] td[class='t_f'] img")
            try:
                for i in ret:
                    url = "https://wuso.me/" + str(i.attrs["file"])
                    print(url)
                    resp.append(url)
            except Exception:
                pass
                
            for each in resp:
                try:
                    img_name = each.split("/")[-1]
                    print("down: {}".format(img_name))
                    head=GetUserAgent("https://wuso.me")
                    ret = urllib.request.Request(each,headers=head)
                    respons = urllib.request.urlopen(ret,timeout=60)
                    with open(img_name,"wb") as fp:
                        fp.write(respons.read())
                        fp.close()
                except Exception:
                    pass
        except Exception:
            pass

        
    
    
    
    
    
    
    
    
    
    
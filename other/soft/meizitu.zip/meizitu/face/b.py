import cv2
import numpy as np

def Display_Face(img_path):
    img = cv2.imread(img_path)                                                  # 读取图片
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)                                # 将图片转化成灰度
    face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml") # 加载级联分类器模型
    face_cascade.load("haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
    # 在原先的彩图上画出包围框(蓝色框,边框宽度为2)
        img = cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 3)
        cv2.namedWindow("img",0);
        cv2.resizeWindow("img", 300, 400);
        cv2.imshow('img', img)
        cv2.waitKey()

def Return_Face(img_path):
    img = cv2.imread(img_path)  
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5)
    if (len(faces) == 0):
        return None,None
    (x, y, w, h) = faces[0]
    return gray[y:y + w, x:x + h], faces[0]


ret = Return_Face("c:\\b.jpg")
print(ret)
Display_Face("c:\\b.jpg")

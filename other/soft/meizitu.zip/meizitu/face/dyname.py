# 人脸识别  https://www.cnblogs.com/do-hardworking/p/9867708.html
# https://www.jb51.net/article/165092.htm



import cv2
import numpy as np

def Video_detected():
    face_cascade=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    eye_cascade=cv2.CascadeClassifier('haarcascade_eye.xml')
    camera=cv2.VideoCapture(0)      # 打开摄像头
    cv2.namedWindow('Dynamic')
    while(True):
        ret,frame=camera.read()
        if ret:
            gray_img=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            faces=face_cascade.detectMultiScale(gray_img,1.3,5)
            for (x,y,w,h) in faces:
                cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)   #蓝色
                roi_gray=gray_img[y:y+h,x:x+w]
                eyes=eye_cascade.detectMultiScale(roi_gray,1.1,5,0,(40,40))
                for (ex,ey,ew,eh) in eyes:
                    cv2.rectangle(frame,(ex+x,ey+y),(ex+x+ew,ey+y+eh),(0,255,0),2)      #绿色
            cv2.imshow('Dynamic',frame)
            if cv2.waitKey(10) & 0xff==ord('q'):
                break
    camera.release()
    cv2.destroyAllWindows()


Video_detected()
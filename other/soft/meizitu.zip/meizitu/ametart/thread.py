import requests,random
from bs4 import BeautifulSoup
import os,re,random,urllib,argparse
from urllib import request,parse
import threading,sys

def GetUserAgent(url):
    head = ["Windows; U; Windows NT 6.1; en-us","Windows NT 6.3; x86_64","Windows U; NT 6.2; x86_64",
    "Windows NT 6.1; WOW64","X11; Linux i686;","X11; Linux x86_64;","compatible; MSIE 9.0; Windows NT 6.1;",
    "X11; Linux i686","Macintosh; U; Intel Mac OS X 10_6_8; en-us","compatible; MSIE 7.0; Windows NT 6.0",
    "Macintosh; Intel Mac OS X 10.6.8; U; en","compatible; MSIE 7.0; Windows NT 5.1","iPad; CPU OS 4_3_3;",]
    fox = ["Chrome/60.0.3100.0","Chrome/59.0.2100.0","Safari/522.13","Chrome/80.0.1211.0","Firefox/74.0",
    "Gecko/20100101 Firefox/4.0.1","Presto/2.8.131 Version/11.11","Mobile/8J2 Safari/6533.18.5",
    "Version/4.0 Safari/534.13","wOSBrowser/233.70 Safari/534.6 TouchPad/1.0","BrowserNG/7.1.18124"]
    agent = "Mozilla/5.0 (" + str(random.sample(head,1)[0]) + ") AppleWebKit/" + str(random.randint(100,1000)) \
    + ".36 (KHTML, like Gecko) " + str(random.sample(fox,1)[0])
    refer = url
    UserAgent = {"User-Agent": agent,"Referer":refer}
    return UserAgent

def run(user):
    head = GetUserAgent("https://aHR0cHM6Ly93d3cuYW1ldGFydC5jb20v")
    ret = requests.get("https://aHR0cHM6Ly93d3cuYW1ldGFydC5jb20vbW9kZWxzL3t9Lw==".format(user),headers=head,timeout=3)
    scan_url = []
    if ret.status_code == 200:
        soup = BeautifulSoup(ret.text,"html.parser")
        a = soup.select("div[class='thumbs'] a")
        for each in a:
            url = "https://aHR0cHM6Ly93d3cuYW1ldGFydC5jb20v" + str(each["href"])
            scan_url.append(url)

    rando = random.choice(scan_url)
    print("随机编号: {}".format(rando))

    try:
        ret = requests.get(url=str(rando),headers=head,timeout=10)
        if ret.status_code == 200:
            soup = BeautifulSoup(ret.text,"html.parser")
            img = soup.select("div[class='container'] div div a")
            try:
                for each in img:
                    head = GetUserAgent(str(each["href"]))
                    down = requests.get(url=str(each["href"]),headers=head)
                    img_name = str(random.randint(100000000,9999999999)) + ".jpg"
                    print("[+] 图片解析: {} 保存为: {}".format(each["href"],img_name))
                    with open(img_name,"wb") as fp:
                        fp.write(down.content)
            except Exception:
                pass
    except Exception:
        exit(1)

if __name__ == "__main__":
    args = sys.argv
    user = str(args[1])
    try:
        os.mkdir(user)
        os.chdir("D://python/ametart/" + user)
        for item in range(100):
            t = threading.Thread(target=run,args=(user,))
            t.start()
    except FileExistsError:
        exit(0)
    
    
    






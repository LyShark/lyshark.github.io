import os,sys
import subprocess



fp = open("lis.log","r")
aaa = fp.readlines()

for i in aaa:
    nam = i.replace("\n","")
    cmd = "python thread.py " + nam
    os.popen(cmd)

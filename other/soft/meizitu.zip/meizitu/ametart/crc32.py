import zlib,os
from operator import itemgetter
from itertools import groupby

def Find_Repeat_File(file_path,file_type):
    Catalogue = os.listdir(file_path)
    CatalogueList = []

    for each in Catalogue:
        path = (file_path + each)
        if os.path.splitext(path)[1] == file_type:
            with open(path,"rb") as fp:
                crc32 = zlib.crc32(fp.read(1024))
                # print("[*] 文件名: {} CRC32校验: {}".format(path,str(crc32)))
                CatalogueList.append({ "CRC32": str(crc32) , "FILE": path })
    # 根据字典中的CRC32排序
    CatalogueList.sort(key=itemgetter("CRC32"))
    for key,value in groupby(CatalogueList,key=itemgetter("CRC32")):
        # print("\n\n [*] CRC32特征码: {}".format(key))
        for each in value:
            if (len(list(value))+1) > 1:
                print("[*] 重复图片: {}".format(each))
                print("[-] 删除图片: {}".format(list(each.values())[1]))
                os.remove(str(list(each.values())[1]))
    
    for each in os.listdir():
        if each.split(".")[1] == "jpg":
            if int(os.stat(each).st_size / 1024) < 100:
                print("[-] 删除 {} 小于100kb的文件.".format(each))
                os.remove(each)
                # n>Bretona<

if __name__ == "__main__":

    while True:
        o = os.listdir()
        for i in o:
            try:
                os.chdir(i)
                Find_Repeat_File("./",".jpg")
                os.chdir("../")
            except:
                pass
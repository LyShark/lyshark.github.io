from bs4 import BeautifulSoup
import requests,os,time
from selenium import webdriver
import win32api,win32con

header = {"User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0"}

def GetPageUrl(name,start_page,end_page):
    key,value = [],[]
    for x in range(start_page,end_page+1):
        url = "https://www.cnblogs.com/{}/default.html?page={}".format(name,x)
        response = requests.get(url,headers=header,timeout=5)
        text = str(response.content.decode("utf-8"))
        bs = BeautifulSoup(text,"html.parser")
        ret = bs.select('div[class="day"] div[class="postTitle"] a')
        for item in range(0,10):
            BlogTitle = ret[item].get_text().replace("\n","").replace(" ","")
            BlogGetUrl = ret[item].get('href').replace("\n","")
            key.append(BlogTitle)
            value.append(BlogGetUrl)
            #print("[+] 爬行地址: {} 标题: {}".format(BlogGetUrl,BlogTitle))
    return key,value

def DownloadUrlKeypad():
    WebPath = "C:/Users/LyShark/AppData/Local/Google/Chrome/Application/chromedriver.exe"
    driver = webdriver.Chrome(executable_path=WebPath)
    driver.set_window_size(1024,768)
    key,value = GetPageUrl("csnd",1,2)
    for item in range(0,len(value)):
        print("[-] 开始保存: {}".format(value[item]))
        driver.get(value[item])
        # 按下ctrl+s
        win32api.keybd_event(0x11, 0, 0, 0)
        win32api.keybd_event(0x53, 0, 0, 0)
        win32api.keybd_event(0x53, 0, win32con.KEYEVENTF_KEYUP, 0)
        win32api.keybd_event(0x11, 0, win32con.KEYEVENTF_KEYUP, 0)
        # 按下回车
        time.sleep(1)
        win32api.keybd_event(0x0D, 0, 0, 0)
        win32api.keybd_event(0x0D, 0, win32con.KEYEVENTF_KEYUP, 0)
        print("[*] 保存完毕: {}".format(value[item]))

def DownloadURLPage(url,Save_Name):
    params = { "encode": "utf-8" }
    response = requests.get(url=url,params=params,headers=header)
    #print("网页编码方式: {} -> {}".format(response.encoding,response.apparent_encoding))
    context = response.text.encode(response.encoding).decode(response.apparent_encoding,"ignore")
    
    file_name = str(Save_Name.replace("/",""))
    if os.mkdir(file_name) == None:
        os.chdir(file_name)
        with open("save.html","w",encoding="utf-8") as fp:
            fp.write(context)
        bs = BeautifulSoup(context, "html.parser")
        ret = bs.select('div[id="cnblogs_post_body"] p img')
        for item in ret:
            img_src_path = item.get("src")
            img_src_name = img_src_path.split("/")[-1]
            print("[+] 下载图片: {} ".format(img_src_name))
            img_download = requests.get(url=img_src_path, headers=header, stream=True)
            with open(img_src_name,"wb") as fp:
                for chunk in img_download.iter_content(chunk_size=1024):
                    fp.write(chunk)
    os.chdir("../")
    return 1

if __name__ == "__main__":
    # 第一个参数是名称,第二个参数为起始页,第三个参数为结束页
    key,value = GetPageUrl("lyshark",1,24)
    for x,y in zip(key,value):
        ret = DownloadURLPage(y,x)
        if ret == 1:
            print("[*] 下载地址: {} 名称: {} 完成".format(y,x))